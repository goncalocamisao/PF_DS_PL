<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Online Petshop Lisboa</title>
    
    <!-- Core CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">  
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">

    <!-- CSS personalizado -->
    <style>
        .title-wrapper {
            cursor: pointer;
            transition: background-color 0.3s;
            text-align: center;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .title-wrapper:hover {
            background-color: #f0f0f0;
        }

        .title-wrapper h2, .title-wrapper h4 {
            font-weight: bold;
        }

        .content {
            text-align: center; /* Centralizando o texto */
            display: none;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
            transition: all 0.3s ease;
            opacity: 0;
            transform: translateY(-20px);
        }

        .content.show {
            display: block;
            opacity: 1;
            transform: translateY(0);
        }
    </style>

    <!-- JavaScript -->
    <script>
        // Função para alternar a visibilidade do conteúdo quando o título é clicado
        function toggleContent(elementId) {
            var content = document.getElementById(elementId);
            if (content.classList.contains("show")) {
                content.classList.remove("show");
            } else {
                content.classList.add("show");
            }
        }
    </script>
</head>

<body>
    <!-- Barra de navegação -->
    <nav class="navbar navbar-inverse" role="banner">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Alternar a navegação</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a href="index.php"><h4 class="wow fadeInDown" style="margin-top:20px; color:#FFF;">
                    Online Petshop Lisboa</h4></a>
            </div>

            <div class="collapse navbar-collapse navbar-right wow fadeInDown">
                <ul class="nav navbar-nav">
                    <li><a href="index.php"><i class="fa fa-home"></i>Início</a></li>
                    <li class="active"><a href="about-us.php">Sobre nós</a></li>
                    <li><a href="available.php">Produtos & Animais</a></li>
                    <li><a href="contacts.php">Contatos</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Conteúdo -->
    <div id="page_about" style="padding: 20px;">
        <div class="title-wrapper" onclick="toggleContent('introducao')">
            <h2>Sobre nós</h2>
        </div>
        <div id="introducao" class="content">
            <p>Bem-vindo à PetShop Lisboa, somos apaixonados por animais e estamos aqui para fornecer os melhores produtos e cuidados para os seus amigos peludos em Lisboa. Oferecemos uma ampla seleção de alimentos, acessórios e produtos de cuidado de alta qualidade. Visite-nos em Lisboa e descubra como podemos ajudar a cuidar dos seus animais de estimação.
</p>
        </div>
        
        <div class="title-wrapper" onclick="toggleContent('missao')">
            <h2>Objetivo</h2>
        </div>
        <div id="missao" class="content">
            <p>Nosso objetivo é ser o destino número um para todos os amantes de animais em Lisboa. Oferecemos uma ampla variedade de produtos de alta qualidade para cuidar e mimar seus animais de estimação. Queremos tornar a vida dos seus animais mais feliz e saudável, proporcionando conveniência e excelência em tudo o que fazemos. Junte-se a nós nessa jornada de amor e cuidado pelos nossos amigos peludos.</p>
        </div>
        
        <div class="title-wrapper" onclick="toggleContent('visao')">
            <h2>Visão</h2>
        </div>
        <div id="visao" class="content">
            <p>Na PetShop Lisboa, a nossa visão é criar uma comunidade de amantes de animais em Lisboa, onde todos os animais de estimação são cuidados com amor, respeito e os melhores produtos disponíveis. Queremos ser reconhecidos como o principal destino para suprimentos e cuidados para animais de estimação, promovendo um estilo de vida saudável e feliz para todos os nossos amigos peludos e suas famílias.</p>
        </div>
    </div>

    <!-- Mapa -->
    <iframe height="400" frameborder="0" style="width: 100%;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6226.656207487648!2d-9.30497028199152!3d38.71027544223127!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd1ec93274e5e081%3A0xd17384b341b1619b!2sOeiras!5e0!3m2!1spt-PT!2spt!4v1706136042930!5m2!1spt-PT!2spt"></iframe>

    <!-- Rodapé -->
    <?php include('includes/footer.php');?>
    <?php include('loginModal.php');?>

    <!-- Scripts JavaScript -->
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>
