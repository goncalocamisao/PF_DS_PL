-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 11-Mar-2024 às 08:06
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `dbcnp`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `admininfo`
--

CREATE TABLE `admininfo` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Extraindo dados da tabela `admininfo`
--

INSERT INTO `admininfo` (`id`, `name`, `contact`, `email`, `username`, `password`) VALUES
(1, 'admin', '+351736485729', 'petshoplisboa@gmail.com', 'admin', '123');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tblcnp`
--

CREATE TABLE `tblcnp` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `prize` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `image` varchar(250) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Extraindo dados da tabela `tblcnp`
--

INSERT INTO `tblcnp` (`id`, `name`, `prize`, `description`, `image`, `status`) VALUES
(1, 'Corrupião-de-baltimore', '350€', 'O Corrupião-de-baltimore é uma ave colorida.', 'images/e.jpg', 'Available'),
(2, 'Maltês', '500€', 'O Maltês é um cão pequeno de pelo longo.do norte.', 'images/2.jpg', 'Available'),
(3, 'Bulldog', '550€', 'O Bulldog é um cão forte e musculoso.', 'images/3.jpg', 'Available'),
(4, 'Setter Gordon', '600€', 'O Setter Gordon é um cão elegante e atlético.', 'images/5.jpg', 'Available'),
(5, 'Bedlington Terrier', '500€', 'O Bedlington é um terrier elegante e dócil.', 'images/9.JPG', 'Available'),
(6, 'Ração Libra', '15€', 'A ração favorita do seu bixinho.', 'images/libra.jpg', 'Available'),
(7, 'Coleção Brinquedos', '20€', 'A coleção perfeita para o seu pet.', 'images/colecao.jpeg', 'Available'),
(8, 'Osso de peluche', '6€', 'Osso para caninos.', 'images/peluche.jpg', 'Un-Available'),
(9, 'Friskies', '10€', 'O snack favorito do seu bixinho.', 'images/friskies.jpg', 'Available');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tblorders`
--

CREATE TABLE `tblorders` (
  `id` int(11) NOT NULL,
  `cname` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `cnpoid` int(11) DEFAULT NULL,
  `oqty` int(11) DEFAULT NULL,
  `ostatus` varchar(50) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `otype` varchar(50) DEFAULT NULL,
  `datepickup` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Extraindo dados da tabela `tblorders`
--

INSERT INTO `tblorders` (`id`, `cname`, `address`, `contact`, `cnpoid`, `oqty`, `ostatus`, `timestamp`, `otype`, `datepickup`) VALUES
(10, 'Rita Gomes', 'Lisboa', '973647364', 4, 1, 'new', '2024-03-11 03:21:02', 'Pick-up', '2016-10-14'),
(11, 'João Alves', 'Porto', '984736473', 3, 3, 'new', '2024-03-11 03:21:33', 'Pick-up', '2019-03-18'),
(12, 'Pedro Sousa', 'Sintra', '984736437', 5, 3, 'new', '2024-03-11 03:22:49', 'Pick-up', '2019-03-27'),
(13, 'Isabel Mendes', 'Setúbal', '937463827', 5, 4, 'new', '2024-03-11 03:24:04', 'Deliver', '2019-05-29');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `admininfo`
--
ALTER TABLE `admininfo`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tblcnp`
--
ALTER TABLE `tblcnp`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tblorders`
--
ALTER TABLE `tblorders`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `admininfo`
--
ALTER TABLE `admininfo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tblcnp`
--
ALTER TABLE `tblcnp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `tblorders`
--
ALTER TABLE `tblorders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
